-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 03, 2022 at 01:44 PM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `library_web_project`
--

-- --------------------------------------------------------

--
-- Table structure for table `book`
--

CREATE TABLE `book` (
  `Bid` int(11) NOT NULL,
  `isbn` char(13) NOT NULL,
  `title` varchar(80) CHARACTER SET latin1 NOT NULL,
  `author` varchar(80) CHARACTER SET latin1 NOT NULL,
  `category` varchar(80) CHARACTER SET latin1 NOT NULL,
  `price` int(5) UNSIGNED NOT NULL,
  `copies` int(10) UNSIGNED NOT NULL,
  `coverUrl` text NOT NULL,
  `pdfUrl` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `book`
--

INSERT INTO `book` (`Bid`, `isbn`, `title`, `author`, `category`, `price`, `copies`, `coverUrl`, `pdfUrl`) VALUES
(2, '0001', 'Book 01', 'Author 01', 'Non-fiction', 120, 12, 'IMG-638b3624b58490.83853223.jpg', 'PDF-638b3624b580b1.00916700.pdf'),
(3, '0002', 'Book 02', 'Author 02', 'Non-fiction', 153, 14, 'IMG-638b369aa3b3f8.61636467.jpg', 'PDF-638b369aa3ac30.14506462.pdf'),
(4, '0003', 'Book 03', 'Author 03', 'Education', 250, 6, 'IMG-638b36e4bb6434.96772485.jpg', 'PDF-638b36e4bb5d57.73032539.pdf'),
(5, '0004', 'Book 04', 'Author 04', 'Education', 100, 25, 'IMG-638b3726c1de06.37204681.jpg', 'PDF-638b3726c1d659.45352384.pdf'),
(6, '0005', 'Book 05', 'Author 05', 'Education', 310, 10, 'IMG-638b377d09e3c2.66857193.jpg', 'PDF-638b377d09de78.28502969.pdf'),
(7, '0006', 'Book 06', 'Author 06', 'Fiction', 45, 13, 'IMG-638b37cf483c83.94209747.jpg', 'PDF-638b37cf4838a9.45721551.pdf'),
(8, '0007', 'Book 07', 'Author 07', 'Fiction', 60, 6, 'IMG-638b3812bf60a1.04760954.jpg', 'PDF-638b3812bf5dc2.68365679.pdf'),
(9, '0009', 'Book 09', 'Author 09', 'Non-fiction', 49, 16, 'IMG-638b38bbecd0a9.13827042.jpg', 'PDF-638b38bbeccc00.07189487.pdf'),
(10, '0008', 'Book 08', 'Author 08', 'Education', 29, 11, 'IMG-638b39d4345805.18538645.jpg', 'PDF-638b39d4345446.88827714.pdf'),
(11, '0010', 'Book 10', 'Author 10', 'Fiction', 56, 42, 'IMG-638b3a293a1443.08856951.jpg', 'PDF-638b3a293a0bb6.13053503.pdf'),
(12, '0011', 'Book 11', 'Author 11', 'Fiction', 78, 63, 'IMG-638b3a84c28099.36497920.jpg', 'PDF-638b3a84c27d07.21542992.pdf'),
(13, '0012', 'Book 12', 'Author 12', 'Non-fiction', 112, 12, 'IMG-638b3acdb88c17.75956520.jpg', 'PDF-638b3acdb88618.53161764.pdf'),
(14, '0013', 'Book 13', 'Author 13', 'Fiction', 12, 62, 'IMG-638b3b11cb85a4.11089315.jpg', 'PDF-638b3b11cb81f5.35846747.pdf'),
(15, '0014', 'Book 14', 'Author 14', 'Education', 54, 13, 'IMG-638b3b51ce5554.23534269.jpg', 'PDF-638b3b51ce50c0.32413330.pdf'),
(16, '0015', 'Book 15', 'Author 15', 'Education', 662, 12, 'IMG-638b3c70f3c5e9.59097707.jpg', 'PDF-638b3c70f3c127.99220739.pdf'),
(17, '0016', 'Book 16', 'Author 16', 'Fiction', 800, 3, 'IMG-638b3d6c3cfca5.06974481.jpg', 'PDF-638b3d6c3cf811.44098890.pdf'),
(18, '0017', 'Book 17', 'Author 17', 'Fiction', 600, 4, 'IMG-638b3db03bb8b4.31564322.jpg', 'PDF-638b3db03bb418.43738387.pdf');

-- --------------------------------------------------------

--
-- Table structure for table `book_issue_log`
--

CREATE TABLE `book_issue_log` (
  `issue_id` int(11) NOT NULL,
  `member` varchar(20) CHARACTER SET latin1 NOT NULL,
  `book_isbn` varchar(13) CHARACTER SET latin1 NOT NULL,
  `due_date` date NOT NULL,
  `last_remainded` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `book_issue_log`
--

INSERT INTO `book_issue_log` (`issue_id`, `member`, `book_isbn`, `due_date`, `last_remainded`) VALUES
(0, 'Amali', '5/', '0000-00-00', '0000-00-00');

-- --------------------------------------------------------

--
-- Table structure for table `librarian`
--

CREATE TABLE `librarian` (
  `id` int(11) NOT NULL,
  `username` varchar(20) CHARACTER SET latin1 NOT NULL,
  `password` varchar(60) CHARACTER SET latin1 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `librarian`
--

INSERT INTO `librarian` (`id`, `username`, `password`) VALUES
(1, 'librarian', 'password');

-- --------------------------------------------------------

--
-- Table structure for table `member`
--

CREATE TABLE `member` (
  `id` int(11) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` char(60) NOT NULL,
  `name` varchar(30) NOT NULL,
  `email` varchar(50) NOT NULL,
  `balance` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `member`
--

INSERT INTO `member` (`id`, `username`, `password`, `name`, `email`, `balance`) VALUES
(3, 'malith', 'ff35e9629f33370f89315562553d37f9d0f856f7', 'Malith Kalinga', 'malith123@kalinga.com', 10896),
(4, 'Janith', 'bc9261b515b1d177e869fb51a13b5699220b61d2', 'Janith Madusanka', 'jnith123@madu.com', 8000),
(5, 'member', 'ff35e9629f33370f89315562553d37f9d0f856f7', 'member', 'member@gmail.com', 8500),
(7, 'Amali', '8c89dfe3948c2b3e0d5d77cf7dfca36bca4f4897', 'Amali Madara', 'hpmalithkalinga@horizoncampus.edu.lk', 501),
(8, 'Asitha', '8c89dfe3948c2b3e0d5d77cf7dfca36bca4f4897', 'Asith Kushal', 'asitha123@kushal.com', 900);

-- --------------------------------------------------------

--
-- Table structure for table `pending_book_requests`
--

CREATE TABLE `pending_book_requests` (
  `request_id` int(11) NOT NULL,
  `member` varchar(20) CHARACTER SET latin1 NOT NULL,
  `book_isbn` varchar(13) CHARACTER SET latin1 NOT NULL,
  `time` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pending_book_requests`
--

INSERT INTO `pending_book_requests` (`request_id`, `member`, `book_isbn`, `time`) VALUES
(28, 'malith', '9/', '2022-12-03 12:33:49');

-- --------------------------------------------------------

--
-- Table structure for table `pending_memreg`
--

CREATE TABLE `pending_memreg` (
  `username` varchar(30) CHARACTER SET latin1 NOT NULL,
  `password` char(40) CHARACTER SET latin1 NOT NULL,
  `name` varchar(80) CHARACTER SET latin1 NOT NULL,
  `email` varchar(80) CHARACTER SET latin1 NOT NULL,
  `balance` int(10) NOT NULL,
  `time` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pending_memreg`
--

INSERT INTO `pending_memreg` (`username`, `password`, `name`, `email`, `balance`, `time`) VALUES
('Janith', 'bc9261b515b1d177e869fb51a13b5699220b61d2', 'Janith Madusanka', 'jnith123@madu.com', 8000, '2022-10-01 03:49:30'),
('Asitha', '8c89dfe3948c2b3e0d5d77cf7dfca36bca4f4897', 'Asith Kushal', 'asitha123@kushal.com', 900, '2022-10-01 04:00:40'),
('member', 'ff35e9629f33370f89315562553d37f9d0f856f7', 'member', 'member@gmail.com', 8500, '2022-10-01 04:05:58');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `book`
--
ALTER TABLE `book`
  ADD PRIMARY KEY (`Bid`);

--
-- Indexes for table `librarian`
--
ALTER TABLE `librarian`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `member`
--
ALTER TABLE `member`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pending_book_requests`
--
ALTER TABLE `pending_book_requests`
  ADD PRIMARY KEY (`request_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `book`
--
ALTER TABLE `book`
  MODIFY `Bid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `librarian`
--
ALTER TABLE `librarian`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `member`
--
ALTER TABLE `member`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `pending_book_requests`
--
ALTER TABLE `pending_book_requests`
  MODIFY `request_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
